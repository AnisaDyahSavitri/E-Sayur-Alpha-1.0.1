/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import model.Order;
import model.OrderList;

/**
 * Chart FXML Controller class
 * Fundamen Pengembangan Aplikasi
 * @author Anisa Dyah Savitri - 19523074
 * Informatika C
 * Tugas besar Miracle - "E-Sayur"
 */


public class ChartController implements Initializable {
    
    private OrderList orderList;

    @FXML
    private LineChart lcOrder;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        this.dataChart();
    }    

    
  private void dataChart(){
        XYChart.Series series = new XYChart.Series<>();
        int a =0, b = 0, c=0, d=0, e=0, f=0, g=0, h=0, i=0;
        
        Iterator<Order> it;
        List<Order> data = new ArrayList();
        orderList = new OrderList();
        orderList.loadXMLFile();
        
        data = Arrays.asList(orderList.getArray());
        
        it = data.iterator();
        
        while(it.hasNext() == true){
            Order or = it.next();
         //   int pcs;
            if(or.getProduct().equals("Wortel")){
               // pcs = or.getPiece();
               // a = a * pcs;
                a += or.getPiece();
            } else if(or.getProduct().equals("Brokoli")){
              //  pcs = or.getPiece();
              // b = b * pcs;
                b += or.getPiece();
            } else if(or.getProduct().equals("Kentang")){
              //  pcs = or.getPiece();
              //  c = c * pcs;
                c += or.getPiece();
            } else if(or.getProduct().equals("Cabe")){
              //  pcs = or.getPiece();
              //  d = d * pcs;
                d += or.getPiece();
            } else if(or.getProduct().equals("Bayam")){
              //  pcs = or.getPiece();
              //  e = e * pcs;
                e += or.getPiece();
            } else if(or.getProduct().equals("Kangkung")){
              //  pcs = or.getPiece();
              //  f = f * pcs;
                f += or.getPiece();
            } else if(or.getProduct().equals("Selada")){
              //  pcs = or.getPiece();
              //  g = g * pcs;
                g += or.getPiece();
            } else if(or.getProduct().equals("Tomat")){
              //  pcs = or.getPiece();
              //  h = h * pcs;
                h += or.getPiece();
            } else if(or.getProduct().equals("Seledri")){
              //  pcs = or.getPiece();
              //  i = i * pcs;
                i += or.getPiece();
            }
            
        }
        series.getData().add(new XYChart.Data("Wortel", a));
        series.getData().add(new XYChart.Data("Brokoli", b));
        series.getData().add(new XYChart.Data("Kentang", c));
        series.getData().add(new XYChart.Data("Cabe", d));
        series.getData().add(new XYChart.Data("Bayam", e));
        series.getData().add(new XYChart.Data("Kangkung", f));
        series.getData().add(new XYChart.Data("Selada", g));
        series.getData().add(new XYChart.Data("Tomat", h));
        series.getData().add(new XYChart.Data("Seledri", i));
        
        lcOrder.getData().addAll(series);
    }
    
    
}
