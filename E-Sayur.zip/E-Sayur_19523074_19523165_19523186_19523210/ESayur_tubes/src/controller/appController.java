/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import model.OrderList;
import model.OrderProperty;


/**
 * AppView FXML Controller class
 * Fundamen Pengembangan Aplikasi
 * @author Anisa Dyah Savitri - 19523074
 * Informatika C
 * Tugas besar Miracle - "E-Sayur"
 */


public class appController implements Initializable {
    
    private OrderList orderList;
    
            // Properti halaman riwayat
    
    @FXML
    private Pane History;
     
    @FXML
    private TableView<OrderProperty> historyTable;
    
    @FXML
    private TableColumn<OrderProperty, String> nameColumn;
    
    @FXML
    private TableColumn<OrderProperty, String> addressColumn;
    
    @FXML
    private TableColumn<OrderProperty, String> noTelpColumn;
    
    @FXML
    private TableColumn<OrderProperty, String> productColumn;
    
    @FXML
    private TableColumn<OrderProperty, Integer> pieceColumn;
     
    @FXML
    private TableColumn<OrderProperty, Integer> paymentColumn;
     
    @FXML
    private TableColumn<OrderProperty, String> statusColumn;
    
            // Pengeditan nama
    @FXML
    public void nameEdit(TableColumn.CellEditEvent<OrderProperty,
            String> nameEdit ){
        OrderProperty order = historyTable.getSelectionModel().getSelectedItem();
        order.setName(nameEdit.getNewValue());
        orderList.saveXMLFile();
    }
    
            // Pengeditan alamat
    @FXML
    public void addressEdit(TableColumn.CellEditEvent<OrderProperty,
            String> addressEdit ){
        OrderProperty order = historyTable.getSelectionModel().getSelectedItem();
        order.setAddress(addressEdit.getNewValue());
        orderList.saveXMLFile();
    }
    
            // Pengeditan nomor telepon
     @FXML
    public void noTelpEdit(TableColumn.CellEditEvent<OrderProperty,
            String> noTelpEdit ){
        OrderProperty order = historyTable.getSelectionModel().getSelectedItem();
        order.setNoTelp(noTelpEdit.getNewValue());
        orderList.saveXMLFile();
    }
    
            // Pengeditan produk
    @FXML
    public void productEdit(TableColumn.CellEditEvent<OrderProperty,
            String> productEdit){
        OrderProperty order = historyTable.getSelectionModel().getSelectedItem();
        order.setProduct(productEdit.getNewValue());
        orderList.saveXMLFile();
    }
    
    
            // Pengeditan pieces
    @FXML
    public void pieceEdit(TableColumn.CellEditEvent<OrderProperty,
            Integer> pieceEdit){
        OrderProperty order = historyTable.getSelectionModel().getSelectedItem();
        order.setPiece(pieceEdit.getNewValue());
        orderList.saveXMLFile();
    }

    
            // Pengeditan Total Pembayaran
    @FXML
    public void paymentEdit(TableColumn.CellEditEvent<OrderProperty,
            Integer> paymentEdit){
        OrderProperty order = historyTable.getSelectionModel().getSelectedItem();
        order.setTotPayment(paymentEdit.getNewValue());
        orderList.saveXMLFile();
    }
    
            // Pengeditan status
    @FXML
    public void statusEdit(TableColumn.CellEditEvent<OrderProperty,
            String> statusEdit){
        OrderProperty order = historyTable.getSelectionModel().getSelectedItem();
        order.setStatus(statusEdit.getNewValue());
        orderList.saveXMLFile();
    }
    
            // Properti halaman beranda
    @FXML
    private Pane Home;
    
            // Properti menu
        // Tombol beranda 
    @FXML
    private void btHome(ActionEvent event){
            // Menampilkan halaman Beranda
       Home.setVisible(true);
       Shop.setVisible(false);
       History.setVisible(false);
    }
    
        // Tombol belanja
    @FXML
    private void btShop(ActionEvent event){
            // Menampilkan halaman Belanja
       Home.setVisible(false);
       Shop.setVisible(true);
       History.setVisible(false);
       
            // Mengosongkan kembali textfield pada halaman belanja
       customerName.setText("");
       customerAddress.setText("");
       productName.setValue("-nama produk-");
       pcs.setText("");
       telpNumber.setText("");
       totalPay.setText("");
       //status.setText("");    
    }
    
        // Tombol riwayat
    @FXML
    private void btHistory(ActionEvent event){
            //Menampilkan halaman History atau riwayat
        Home.setVisible(false);
        Shop.setVisible(false);
        History.setVisible(true);
      
            // Mengedit data dari kolom terpilih pada tabel riwayat  
       historyTable.setEditable(true);
       nameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       addressColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       noTelpColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       productColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       pieceColumn.setCellFactory(TextFieldTableCell.forTableColumn
        (new IntegerStringConverter()));
       paymentColumn.setCellFactory(TextFieldTableCell.forTableColumn
        (new IntegerStringConverter()));
       statusColumn.setCellFactory(TextFieldTableCell.forTableColumn());
      
    }
    
    /**
     * Initializes the controller class.
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            // Menutup halaman Belanja, Riwayat, dan Statistik 
                //agar dapat menampilkan Beranda 
       Shop.setVisible(false);
       History.setVisible(false);
       
       productName.getItems().addAll( "-nama produk-", "Wortel", "Brokoli", 
               "Kentang", "Cabe", "Bayam", "Kangkung", "Selada", "Tomat", 
               "Seledri");
       productName.setValue("-nama produk-");
       
            // Mengambil data dari file XML
       orderList = new OrderList(); 
       
            // Mengakses file XML
       orderList.loadXMLFile();
       
            // Mengambil data dari file XML lalu mengisi data ke tabel
       System.out.println(orderList.getArray()); 
       historyTable.setItems(orderList.get());
       
            //Inisialisasi setiap kolom tabel
       nameColumn.setCellValueFactory(cellData -> cellData.getValue().
               getNameProperty());
       addressColumn.setCellValueFactory(cellData -> cellData.getValue().
               getAddressProperty());
       noTelpColumn.setCellValueFactory(cellData -> cellData.getValue().
               getNoTelpProperty());
       productColumn.setCellValueFactory(cellData -> cellData.getValue().
               getProductProperty());
       pieceColumn.setCellValueFactory(cellData -> cellData.getValue().
               getPieceProperty().asObject());
       paymentColumn.setCellValueFactory(cellData -> cellData.getValue().
               getTotPaymentProperty().asObject());
       statusColumn.setCellValueFactory(cellData -> cellData.getValue().
               getStatusProperty());
       
            // Pengeditan data pada kolom terpilih
       historyTable.setEditable(true);
       nameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       addressColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       noTelpColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       productColumn.setCellFactory(TextFieldTableCell.forTableColumn());
       pieceColumn.setCellFactory(TextFieldTableCell.forTableColumn
        (new IntegerStringConverter()));
       paymentColumn.setCellFactory(TextFieldTableCell.forTableColumn
        (new IntegerStringConverter()));
       statusColumn.setCellFactory(TextFieldTableCell.forTableColumn());
    }    
    
    
             // Properti halaman belanja
    
    @FXML
    private Pane Shop;
    
    @FXML
    private ChoiceBox productName;
    
    @FXML
    private TextField pcs;
    
    @FXML
    private TextField totalPay;
    
    @FXML
    private TextField customerName;
    
    @FXML
    private TextField customerAddress;
    
    @FXML
    private TextField telpNumber;
    
        // Tombol set
    @FXML
    private void btSet(ActionEvent event) throws IOException{      
        int productPrice = 0;
     
        if(productName.getValue().equals("Wortel")){
            productPrice = 5000;
        } else if(productName.getValue().equals("Brokoli")){
            productPrice = 10000;
        } else if(productName.getValue().equals("Kentang")){
            productPrice = 7500;
        } else if(productName.getValue().equals("Cabe")){
            productPrice = 6000;
        } else if(productName.getValue().equals("Bayam")){
           productPrice = 4000;
        } else if(productName.getValue().equals("Kangkung")){
            productPrice = 5000;
        } else if(productName.getValue().equals("Selada")){
            productPrice = 10000;
        } else if(productName.getValue().equals("Tomat")){
            productPrice = 10000;
        } else if(productName.getValue().equals("Seledri")){
            productPrice = 4000;
        }
        
       try{ 
        String s;
        int piece, totPay;
        s = pcs.getText();
        piece = Integer.parseInt(s);

        totPay = piece * productPrice;
        
        s = String.valueOf(totPay);
        totalPay.setText(s);
       } catch (RuntimeException e){
           Alert alert = new Alert(AlertType.WARNING);
           alert.setTitle("Perhatian!");
           alert.setHeaderText("Tipe data isian salah");
           alert.setContentText("Pieces harus bilangan");
           alert.showAndWait();
       }
    }
    
        // Tombol beli
    @FXML
    private void btBuy(ActionEvent event) throws IOException{
            // Menyimpan data yang telah diisi ke kelas OrderProperty
       OrderProperty order = new OrderProperty();
       
     try {
       order.setName(customerName.getText());
       order.setAddress(customerAddress.getText());
       order.setNoTelp(telpNumber.getText());
       order.setPiece(Integer.parseInt(pcs.getText()));

         if(productName.getValue().equals("Wortel")){
            order.setProduct("Wortel");
        } else if(productName.getValue().equals("Brokoli")){
            order.setProduct("Brokoli");
        } else if(productName.getValue().equals("Kentang")){
            order.setProduct("Kentang");
        } else if(productName.getValue().equals("Cabe")){
            order.setProduct("Cabe");
        } else if(productName.getValue().equals("Bayam")){
           order.setProduct("Bayam");
        } else if(productName.getValue().equals("Kangkung")){
            order.setProduct("Kangkung");
        } else if(productName.getValue().equals("Selada")){
            order.setProduct("Selada");
        } else if(productName.getValue().equals("Tomat")){
            order.setProduct("Tomat");
        } else if(productName.getValue().equals("Seledri")){
            order.setProduct("Seledri");
        }
       order.setTotPayment(Integer.parseInt(totalPay.getText()));
       order.setStatus("Belum dibayar");
       
            // Menambahkan data yang telah ditambahkan ke dalam tabel
       historyTable.getItems().add(order);
       
            // Menyimpan data yang telah ditambahkan ke dalam file XML
       orderList.saveXMLFile();
     } catch (RuntimeException e){
            // Peringatan bahwa data telah disimpan
       Alert alert = new Alert(Alert.AlertType.INFORMATION);
       alert.setTitle("Information Dialog");
       alert.setHeaderText(null);
       alert.setContentText("Harap isi semua data");  
       alert.showAndWait();
     } finally {
       Alert alert = new Alert(Alert.AlertType.INFORMATION);
       alert.setTitle("Information Dialog");
       alert.setHeaderText(null);
       alert.setContentText("Data telah disimpan");  
       alert.showAndWait();
     }
        // Mengembalikan isi textfield dan choicebox menjadi kosong 
      customerName.setText("");
      customerAddress.setText("");
      productName.setValue("-nama produk-");
      pcs.setText("");
      telpNumber.setText("");
      totalPay.setText("");
     
    }
    
            // Properti halaman riwayat
        // Tombol telah dibayar 
    @FXML
    private void btFinish(ActionEvent event){
            // Mengubah status data terpilih pada tabel
               //dari belum dibayar menjadi telah dibayar
        try{    
         OrderProperty order = new OrderProperty();
         order = historyTable.getSelectionModel().getSelectedItem();
         order.setStatus("Telah dibayar");
         orderList.saveXMLFile();
        } catch (RuntimeException e){
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Informasi");
            alert.setHeaderText(null);
            alert.setContentText("Belum ada data yang dipilih");
            alert.showAndWait();
        }  
    }
    
        // Tombol hapus data
    @FXML
    private void btDelete(ActionEvent event){
            // Menghapus data terpilih dari file XML dan juga dari tabel
        try {
            int picked = historyTable.getSelectionModel().getSelectedIndex();
            if(picked>= 0){
                historyTable.getItems().remove(picked);   
            } 
        orderList.saveXMLFile();
        } catch (RuntimeException e){
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Informasi");
            alert.setHeaderText(null);
            alert.setContentText("Belum ada data yang dipilih");
            alert.showAndWait();
        }
    }
  
        // Tombol grafik statistik
    @FXML
    private void btStatistic(ActionEvent event)throws IOException{
           
            // Menampilkan grafik statistik pembelian berupa scene baru
        
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(ChartController.class.getResource
                ("/view/Chart.fxml"));
        AnchorPane contentArea = (AnchorPane) loader.load();
        Scene scene = new Scene(contentArea);

        Stage stage = new Stage();
        stage.setTitle("Statistik");
        
        ChartController controller = loader.getController();
        
        stage.setScene(scene);
        stage.show();
    }

    
}
