/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Fundamen Pengembangan Aplikasi
 * @author Anisa Salsabila - 19523186
 * Informatika C
 * Tugas besar Miracle - "E-Sayur"
 */
public class OrderList {
    private ObservableList<OrderProperty> list;
    private  String fileOrder;
    
    public OrderList(){
        list = FXCollections.observableArrayList();
        fileOrder = "orderData.xml";
    }
    
    public ObservableList<OrderProperty> get(){
        return list;
    }  
    
    public void setFromArray(Order[] array){
        list = FXCollections.observableArrayList();
        
        for (Order o : array){
            
            list.add(new OrderProperty(o.getName(), o.getAddress(), 
                     o.getNoTelp(),o.getProduct(), o.getPiece(),
                    o.getTotPayment(), o.getStatus()));
        }
    }
    
    public void loadXMLFile(){
        try{
           XStream xs = new XStream (new StaxDriver());
           FileInputStream input = new FileInputStream(fileOrder);
           String s = "";
            int c = input.read();
           
           
            while (c != -1){
                s += (char) c;
                c = input.read();
            }
            Order[] array = (Order[]) xs.fromXML(s);
            this.setFromArray(array);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    
     public Order[] getArray(){
         //Memanggil property
         OrderProperty order = new OrderProperty();
         // Memasukkan data ke dalam array baru
         Order[] array = new Order[list.size()];
         for (int i = 0; i < list.size(); i++){
             String name = list.get(i).getName();
             String address = list.get(i).getAddress();
             String noTelp = list.get(i).getNoTelp();
             String product = list.get(i).getProduct();
             int piece = list.get(i).getPiece();
             int totPay = list.get(i).getTotPayment();
             String status = list.get(i).getStatus();
             array[i] = new Order(name, address,noTelp,
                     product, piece, totPay, status);
        }
                 
        return array;       
     }
    
    public void saveXMLFile(){
        Order[] array = this.getArray();
        XStream xs = new XStream (new StaxDriver());
        String xml = xs.toXML(array);
        
        try{
            FileOutputStream output = new FileOutputStream(fileOrder); 
            byte[] bytes = xml.getBytes();
            output.write(bytes);
            output.close();
        }catch(Exception e){
           e.printStackTrace(); 
        }
    }
}
