/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Fundamen Pengembangan Aplikasi
 * @author Adelia Maharani - 19523210
 * Informatika C
 * Tugas besar Miracle - "E-Sayur"
 * 
 */
public class OrderProperty {
    private StringProperty name;
    private StringProperty address;
    private StringProperty noTelp;
    private StringProperty product;
    private IntegerProperty piece;
    private IntegerProperty totPayment;
    private StringProperty status;

    public OrderProperty(String name, String address, String noTelp, 
            String product,int piece, int totPayment, String status) {
        this.name = new SimpleStringProperty(name);
        this.address = new SimpleStringProperty(address);
        this.noTelp = new SimpleStringProperty(noTelp);
        this.product = new SimpleStringProperty(product);
        this.piece = new SimpleIntegerProperty(piece);
        this.totPayment = new SimpleIntegerProperty(totPayment);
        this.status = new SimpleStringProperty(status);
    }
    
    public OrderProperty(){
        this("","","","",0, 0, "Belum dibayar"); 
    }
    
    //getter Name Property
    public StringProperty getNameProperty(){
        return name;
    }
    //getter Name
    public String getName(){
        return this.name.get();
    }
    //setter Name
    public void setName(String name){
        this.name.set(name);
    }
    
    //getter AddressProperty
    public StringProperty getAddressProperty(){
        return address;
    }
    //getter Address
    public String getAddress(){
        return this.address.get();
    }
    //setter Address
    public void setAddress(String address){
        this.address.set(address);
    }
    
    //getter NoTelpProperty
    public StringProperty getNoTelpProperty(){
        return noTelp;
    }
    //getter NoTelp
    public String getNoTelp(){
        return this.noTelp.get();
    }
    //setter NoTelpProperty
    public void setNoTelp(String noTelp){
        this.noTelp.set(noTelp);
    }
    
    //getter ProductProperty
     public StringProperty getProductProperty(){
        return product;
    }
    //getter Product
    public String getProduct(){
        return this.product.get();
    }
    //setter Product
    public void setProduct(String product){
        this.product.set(product);
    }
    
    //getter Pieces Property
     public IntegerProperty getPieceProperty(){
        return piece;
    }
    //getter Pieces
    public Integer getPiece(){
        return this.piece.get();
    }
    //setter Pieces
    public void setPiece(int totPayment){
        this.piece.set(totPayment);
    }
    
    //getter Total Payment Property
     public IntegerProperty getTotPaymentProperty(){
        return totPayment;
    }
    //getter Total Payment
    public Integer getTotPayment(){
        return this.totPayment.get();
    }
    //setter Total Payment
    public void setTotPayment(int totPayment){
        this.totPayment.set(totPayment);
    }
    
    //getter StatusProperty
     public StringProperty getStatusProperty(){
        return status;
    }
    //getter Status
    public String getStatus(){
        return this.status.get();
    }
    //setter Status
    public void setStatus(String status){
        this.status.set(status);
    }
}
