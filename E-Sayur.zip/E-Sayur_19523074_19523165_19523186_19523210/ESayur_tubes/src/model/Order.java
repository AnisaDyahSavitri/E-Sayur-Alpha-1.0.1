/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * Fundamen Pengembangan Aplikasi
 * @author Rafiqoh Salas Maharani - 19523165
 * Informatika C
 * Tugas besar Miracle - "E-Sayur"
 */
public class Order {
    private String name;
    private String address;
    private String noTelp;
    private String product;
    private int piece;
    private int totPayment;
    private String status;

    public Order(String name, String address, String noTelp, String product, 
            int piece, int totPayment, String status) {
        this.name = name;
        this.address = address;
        this.noTelp = noTelp;
        this.product = product;
        this.piece = piece;
        this.totPayment = totPayment;
        this.status = status;
    }
    
    public Order(){
        this.name = "";
        this.address = "";
        this.noTelp = "";
        this.product = "";
        this.piece = 0;
        this.totPayment = 0;
        this.status = "Belum dibayar";
    }
    //getter Name
    public String getName() {
        return name;
    }
    //setter Name
    public void setName(String name) {
        this.name = name;
    }
    //getter Address
    public String getAddress() {
        return address;
    }
    //setter Address
    public void setAddres(String address) {
        this.address = address;
    }
    //getter NoTelp
    public String getNoTelp() {
        return noTelp;
    }
    //setter NoTelp
    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }
    //getter Product
    public String getProduct() {
        return product;
    }
    //setter Product
    public void setProduct(String product) {
        this.product = product;
    }
    
    //getter Pieces
    public int getPiece() {
        return piece;
    }
    //setter Pieces
    public void setPiece(int piece) {
        this.piece = piece;
    }

    //getter Total Payment
    public int getTotPayment() {
        return totPayment;
    }
    //setter TotalPayment
    public void setTotPayment(int totPayment) {
        this.totPayment = totPayment;
    }
    
    //getter Status
    public String getStatus() {
        return status;
    }
    //setter Status
    public void setStatus(String status) {
        this.status = status;
        status = "Belum dibayar";
    }
}
